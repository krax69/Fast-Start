import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import psutil
import json
import os
import threading
import time

# Извлечение реальных иконок (.exe и ярлыков .lnk) — опционально.
# Если pywin32 и Pillow не установлены, программа всё равно работает,
# просто вместо иконок используются заглушки.
# Установка: pip install pywin32 Pillow
try:
    from PIL import Image, ImageTk
    import win32gui
    import win32ui
    import win32com.client
    ICONS_AVAILABLE = True
except ImportError:
    ICONS_AVAILABLE = False

# Флаги для SHGetFileInfo — та же функция Windows, которой пользуется
# Проводник и Рабочий стол для отображения иконок (в т.ч. у ярлыков .lnk).
SHGFI_ICON = 0x000000100
SHGFI_LARGEICON = 0x000000000

DESKTOP_DIR = os.path.join(os.path.expanduser("~"), "Desktop")
SCENARIOS_FILE = "scenarios.json"

# ---------- Цветовая схема (тёмная тема) ----------
BG_MAIN = "#121212"
BG_PANEL = "#1a1a1a"
BG_CARD = "#232323"
BG_CARD_SELECTED = "#2d2d2d"
ACCENT = "#00d4ff"
ACCENT_GREEN = "#00ff88"
ACCENT_RED = "#ff4d4d"
ACCENT_ORANGE = "#ffaa00"
TEXT_MAIN = "#f2f2f2"
TEXT_DIM = "#9a9a9a"

FONT_TITLE = ("Segoe UI", 20, "bold")
FONT_SUBTITLE = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 13, "bold")
FONT_NORMAL = ("Segoe UI", 10)
FONT_SMALL = ("Segoe UI", 9)


# ---------------------------------------------------------------------------
# Иконки
# ---------------------------------------------------------------------------

def resolve_shortcut_target(path):
    """Если это ярлык (.lnk), возвращает путь к реальной программе.
    Иначе возвращает сам путь без изменений."""
    if ICONS_AVAILABLE and path.lower().endswith(".lnk"):
        try:
            shell = win32com.client.Dispatch("WScript.Shell")
            target = shell.CreateShortcut(path).Targetpath
            if target:
                return target
        except Exception:
            pass
    return path


def extract_icon(path, size=48):
    """Извлекает настоящую иконку файла тем же способом, что и Проводник /
    Рабочий стол Windows (SHGetFileInfo) — работает и для .exe, и для .lnk.
    Возвращает PhotoImage или None, если извлечь не удалось."""
    if not ICONS_AVAILABLE or not path or not os.path.exists(path):
        return None

    hicon = None
    hdc_screen = None
    hdc = None
    hdc_mem = None
    try:
        info = win32gui.SHGetFileInfo(path, 0, SHGFI_ICON | SHGFI_LARGEICON)
        hicon = info[0]
        if not hicon:
            return None

        hdc_screen = win32gui.GetDC(0)
        hdc = win32ui.CreateDCFromHandle(hdc_screen)
        hbmp = win32ui.CreateBitmap()
        hbmp.CreateCompatibleBitmap(hdc, size, size)
        hdc_mem = hdc.CreateCompatibleDC()
        hdc_mem.SelectObject(hbmp)
        hdc_mem.DrawIcon((0, 0), hicon)

        bmpinfo = hbmp.GetInfo()
        bmpstr = hbmp.GetBitmapBits(True)
        img = Image.frombuffer(
            "RGBA",
            (bmpinfo["bmWidth"], bmpinfo["bmHeight"]),
            bmpstr, "raw", "BGRA", 0, 1
        )
        img = img.resize((size, size), Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None
    finally:
        if hicon:
            win32gui.DestroyIcon(hicon)
        if hdc_mem:
            hdc_mem.DeleteDC()
        if hdc:
            hdc.DeleteDC()
        if hdc_screen:
            win32gui.ReleaseDC(0, hdc_screen)


# ---------------------------------------------------------------------------
# Прокручиваемая область
# ---------------------------------------------------------------------------

class ScrollableFrame(tk.Frame):
    """Прокручиваемая область (используется и для списка сценариев,
    и для сетки плиток с программами)."""

    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)

        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)

        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._on_mousewheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def _on_canvas_resize(self, event):
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


# ---------------------------------------------------------------------------
# Диалог добавления программы (путь + задержка с выбором ▲▼)
# ---------------------------------------------------------------------------

class AddProgramDialog(tk.Toplevel):
    def __init__(self, parent, initial_dir):
        super().__init__(parent)
        self.result = None
        self.initial_dir = initial_dir

        self.title("Добавить программу")
        self.configure(bg=BG_PANEL)
        self.resizable(False, False)
        self.transient(parent)

        self.path_var = tk.StringVar()

        tk.Label(
            self, text="Программа или ярлык", font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_MAIN
        ).pack(anchor="w", padx=20, pady=(20, 5))

        path_frame = tk.Frame(self, bg=BG_PANEL)
        path_frame.pack(fill="x", padx=20)

        self.path_entry = tk.Entry(
            path_frame, textvariable=self.path_var, bg=BG_CARD, fg=TEXT_MAIN,
            relief="flat", state="readonly", readonlybackground=BG_CARD,
            font=FONT_SMALL, width=40,
        )
        self.path_entry.pack(side="left", fill="x", expand=True, ipady=6)

        tk.Button(
            path_frame, text="Обзор...", command=self._browse, bg=ACCENT, fg="black",
            relief="flat", font=FONT_SMALL, cursor="hand2", bd=0, padx=12, pady=4,
        ).pack(side="left", padx=(8, 0))

        tk.Label(
            self, text="Задержка запуска", font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_MAIN
        ).pack(anchor="w", padx=20, pady=(20, 5))

        delay_frame = tk.Frame(self, bg=BG_PANEL)
        delay_frame.pack(padx=20, anchor="w")

        self.delay_var = tk.IntVar(value=0)
        self.delay_spin = tk.Spinbox(
            delay_frame, from_=0, to=3600, textvariable=self.delay_var,
            width=8, font=("Segoe UI", 13), bg=BG_CARD, fg=TEXT_MAIN,
            relief="flat", buttonbackground=ACCENT, insertbackground=TEXT_MAIN,
            justify="center", wrap=False,
        )
        self.delay_spin.pack(side="left", ipady=8)
        tk.Label(
            delay_frame, text="сек", font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_DIM
        ).pack(side="left", padx=(10, 0))

        btn_row = tk.Frame(self, bg=BG_PANEL)
        btn_row.pack(fill="x", padx=20, pady=20)

        tk.Button(
            btn_row, text="Отмена", command=self._cancel, bg="#333333", fg=TEXT_MAIN,
            relief="flat", font=FONT_NORMAL, cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right", padx=(8, 0))

        tk.Button(
            btn_row, text="Добавить", command=self._confirm, bg=ACCENT_GREEN, fg="black",
            relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right")

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.update_idletasks()
        self._center_over(parent)

        self.grab_set()
        self.wait_window(self)

    def _center_over(self, parent):
        parent.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Выберите программу или ярлык",
            initialdir=self.initial_dir,
            parent=self,
            filetypes=[
                ("Программы и ярлыки", "*.exe *.lnk"),
                ("Программы (.exe)", "*.exe"),
                ("Ярлыки (.lnk)", "*.lnk"),
                ("Все файлы", "*.*"),
            ],
        )
        if path:
            self.path_var.set(path)

    def _confirm(self):
        path = self.path_var.get().strip()
        if not path:
            messagebox.showwarning("Внимание", "Сначала выберите программу.", parent=self)
            return
        try:
            delay = int(self.delay_var.get())
        except (tk.TclError, ValueError):
            delay = 0

        self.result = {"path": path, "delay": max(0, delay)}
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


# ---------------------------------------------------------------------------
# Основное приложение
# ---------------------------------------------------------------------------

class FastStart:
    def __init__(self, root):
        self.root = root
        self.root.title("🚀 Fast Start")
        self.root.geometry("1000x620")
        self.root.minsize(780, 480)
        self.root.configure(bg=BG_MAIN)

        self.scenarios = self.load_scenarios()
        self.icon_cache = {}
        self.selected_scenario_name = None
        self.selected_program_index = None
        self.scenario_rows = {}

        self._build_ui()
        self.refresh_scenarios()

    # ---------------------------------------------------------------
    # Построение интерфейса
    # ---------------------------------------------------------------

    def _build_ui(self):
        header = tk.Frame(self.root, bg=BG_MAIN)
        header.pack(fill="x", padx=20, pady=(15, 5))

        tk.Label(
            header, text="🚀 Fast Start", font=FONT_TITLE, bg=BG_MAIN, fg=ACCENT
        ).pack(side="left")

        tk.Label(
            header, text="Менеджер сценариев запуска", font=FONT_SUBTITLE,
            bg=BG_MAIN, fg=TEXT_DIM
        ).pack(side="left", padx=(15, 0), pady=(7, 0))

        main_frame = tk.Frame(self.root, bg=BG_MAIN)
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # ---------------- Левая панель: сценарии ----------------
        left_frame = tk.Frame(main_frame, bg=BG_PANEL, width=260)
        left_frame.pack(side="left", fill="y", padx=(0, 15))
        left_frame.pack_propagate(False)

        tk.Label(
            left_frame, text="Сценарии", font=FONT_HEADER, bg=BG_PANEL, fg=TEXT_MAIN
        ).pack(pady=(15, 10), padx=15, anchor="w")

        list_area = tk.Frame(left_frame, bg=BG_PANEL)
        list_area.pack(fill="both", expand=True, padx=15)

        self.scenario_scroll = ScrollableFrame(list_area, BG_PANEL)
        self.scenario_scroll.pack(fill="both", expand=True)
        self.scenario_list_frame = self.scenario_scroll.inner

        btns = tk.Frame(left_frame, bg=BG_PANEL)
        btns.pack(fill="x", padx=15, pady=15)

        self._make_button(btns, "➕ Создать", ACCENT, "black", self.create_scenario).pack(fill="x", pady=3)
        self._make_button(btns, "✏ Переименовать", ACCENT_ORANGE, "black", self.rename_scenario).pack(fill="x", pady=3)
        self._make_button(btns, "🗑 Удалить", ACCENT_RED, "white", self.delete_scenario).pack(fill="x", pady=3)

        status_text = (
            "🟢 Иконки включены" if ICONS_AVAILABLE
            else "⚪ Иконки выключены\npip install pywin32 Pillow"
        )
        status_color = ACCENT_GREEN if ICONS_AVAILABLE else TEXT_DIM
        tk.Label(
            left_frame, text=status_text, font=FONT_SMALL, bg=BG_PANEL,
            fg=status_color, justify="left",
        ).pack(padx=15, pady=(0, 15), anchor="w")

        # ---------------- Правая панель: программы ----------------
        right_frame = tk.Frame(main_frame, bg=BG_PANEL)
        right_frame.pack(side="right", fill="both", expand=True)

        right_header = tk.Frame(right_frame, bg=BG_PANEL)
        right_header.pack(fill="x", padx=20, pady=(15, 5))

        self.programs_title = tk.Label(
            right_header, text="Программы", font=FONT_HEADER, bg=BG_PANEL, fg=TEXT_MAIN
        )
        self.programs_title.pack(side="left")

        self.scroll_area = ScrollableFrame(right_frame, BG_PANEL)
        self.scroll_area.pack(fill="both", expand=True, padx=15, pady=10)

        bottom_bar = tk.Frame(right_frame, bg=BG_PANEL)
        bottom_bar.pack(fill="x", padx=20, pady=(0, 15))

        self._make_button(bottom_bar, "➕ Добавить программу", ACCENT, "black", self.add_program).pack(side="left", padx=(0, 8))
        self._make_button(bottom_bar, "❌ Удалить программу", ACCENT_RED, "white", self.remove_program).pack(side="left")

        self._make_button(bottom_bar, "⛔ Остановить", "#ff4444", "white", self.stop_scenario, bold=True).pack(side="right", padx=(8, 0))
        self._make_button(bottom_bar, "🚀 Запустить сценарий", ACCENT_GREEN, "black", self.run_scenario, bold=True).pack(side="right")

    def _make_button(self, parent, text, bg, fg, command, bold=False):
        return tk.Button(
            parent, text=text, command=command, bg=bg, fg=fg,
            relief="flat", activebackground=bg, activeforeground=fg,
            font=("Segoe UI", 10, "bold" if bold else "normal"),
            cursor="hand2", bd=0, padx=10, pady=8,
        )

    # ---------------------------------------------------------------
    # Работа с файлом сценариев
    # ---------------------------------------------------------------

    def load_scenarios(self):
        if os.path.exists(SCENARIOS_FILE):
            try:
                with open(SCENARIOS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def save_scenarios(self):
        with open(SCENARIOS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.scenarios, f, ensure_ascii=False, indent=4)

    # ---------------------------------------------------------------
    # Сценарии — свои плашки вместо Listbox, чтобы выделение
    # никогда не пропадало при потере фокуса окном.
    # ---------------------------------------------------------------

    def refresh_scenarios(self):
        for widget in self.scenario_list_frame.winfo_children():
            widget.destroy()
        self.scenario_rows = {}

        if self.selected_scenario_name not in self.scenarios:
            self.selected_scenario_name = None

        if not self.scenarios:
            tk.Label(
                self.scenario_list_frame, text="Нет сценариев.\nНажмите «Создать».",
                font=FONT_SMALL, bg=BG_PANEL, fg=TEXT_DIM, justify="left",
            ).pack(pady=15, anchor="w")

        for name in self.scenarios:
            row = tk.Frame(self.scenario_list_frame, bg=BG_CARD, cursor="hand2")
            row.pack(fill="x", pady=3)

            label = tk.Label(
                row, text=name, font=FONT_NORMAL, bg=BG_CARD, fg=TEXT_MAIN,
                anchor="w", padx=10, pady=8,
            )
            label.pack(fill="x")

            for widget in (row, label):
                widget.bind("<Button-1>", lambda e, n=name: self.select_scenario(n))

            self.scenario_rows[name] = (row, label)

        if self.selected_scenario_name is None and self.scenarios:
            self.selected_scenario_name = next(iter(self.scenarios))

        self._highlight_scenario_selection()
        self.load_programs()

    def _highlight_scenario_selection(self):
        for name, (row, label) in self.scenario_rows.items():
            selected = name == self.selected_scenario_name
            bg = ACCENT if selected else BG_CARD
            fg = "black" if selected else TEXT_MAIN
            row.configure(bg=bg)
            label.configure(bg=bg, fg=fg)

    def select_scenario(self, name):
        self.selected_scenario_name = name
        self._highlight_scenario_selection()
        self.load_programs()

    def get_selected_scenario(self):
        return self.selected_scenario_name

    def create_scenario(self):
        name = self._prompt_text("Создать сценарий", "Введите имя сценария:")
        if not name:
            return
        if name in self.scenarios:
            messagebox.showerror("Ошибка", "Такой сценарий уже существует.")
            return

        self.scenarios[name] = []
        self.selected_scenario_name = name
        self.save_scenarios()
        self.refresh_scenarios()

    def rename_scenario(self):
        old_name = self.get_selected_scenario()
        if not old_name:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return

        new_name = self._prompt_text("Переименование", "Новое имя:", initial=old_name)
        if not new_name or new_name == old_name:
            return
        if new_name in self.scenarios:
            messagebox.showerror("Ошибка", "Сценарий с таким именем уже существует.")
            return

        self.scenarios[new_name] = self.scenarios.pop(old_name)
        self.selected_scenario_name = new_name
        self.save_scenarios()
        self.refresh_scenarios()

    def delete_scenario(self):
        name = self.get_selected_scenario()
        if not name:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return

        if messagebox.askyesno("Удаление", f"Удалить сценарий «{name}»?"):
            del self.scenarios[name]
            self.selected_scenario_name = None
            self.save_scenarios()
            self.refresh_scenarios()

    def _prompt_text(self, title, message, initial=""):
        """Простое модальное окно ввода текста в тёмной теме."""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg=BG_PANEL)
        dialog.resizable(False, False)
        dialog.transient(self.root)

        result = {"value": None}

        tk.Label(dialog, text=message, font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_MAIN).pack(
            padx=20, pady=(20, 10), anchor="w"
        )

        var = tk.StringVar(value=initial)
        entry = tk.Entry(
            dialog, textvariable=var, bg=BG_CARD, fg=TEXT_MAIN, relief="flat",
            insertbackground=TEXT_MAIN, font=FONT_NORMAL, width=30,
        )
        entry.pack(padx=20, ipady=6, fill="x")
        entry.focus_set()
        entry.select_range(0, tk.END)

        def confirm():
            value = var.get().strip()
            if value:
                result["value"] = value
            dialog.destroy()

        def cancel():
            dialog.destroy()

        btn_row = tk.Frame(dialog, bg=BG_PANEL)
        btn_row.pack(fill="x", padx=20, pady=20)

        tk.Button(
            btn_row, text="Отмена", command=cancel, bg="#333333", fg=TEXT_MAIN,
            relief="flat", font=FONT_NORMAL, cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right", padx=(8, 0))

        tk.Button(
            btn_row, text="ОК", command=confirm, bg=ACCENT_GREEN, fg="black",
            relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right")

        dialog.bind("<Return>", lambda e: confirm())
        dialog.bind("<Escape>", lambda e: cancel())
        dialog.protocol("WM_DELETE_WINDOW", cancel)

        dialog.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - dialog.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{max(x, 0)}+{max(y, 0)}")

        dialog.grab_set()
        dialog.wait_window(dialog)
        return result["value"]

    # ---------------------------------------------------------------
    # Программы (плитки с иконками)
    # ---------------------------------------------------------------

    def load_programs(self, event=None):
        for widget in self.scroll_area.inner.winfo_children():
            widget.destroy()
        self.selected_program_index = None

        name = self.get_selected_scenario()
        if not name:
            self.programs_title.config(text="Программы")
            tk.Label(
                self.scroll_area.inner,
                text="Выберите или создайте сценарий слева.",
                font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_DIM,
            ).pack(pady=30)
            return

        programs = self.scenarios.get(name, [])
        self.programs_title.config(text=f"Программы — {name} ({len(programs)})")

        if not programs:
            tk.Label(
                self.scroll_area.inner,
                text="Сценарий пуст. Нажмите «Добавить программу».",
                font=FONT_NORMAL, bg=BG_PANEL, fg=TEXT_DIM,
            ).pack(pady=30)
            return

        columns = 4
        for col in range(columns):
            self.scroll_area.inner.grid_columnconfigure(col, weight=1)

        for idx, item in enumerate(programs):
            row, col = divmod(idx, columns)
            self._create_program_tile(item, idx, row, col)

    def _create_program_tile(self, item, index, row, col):
        path = item.get("path", "")
        delay = item.get("delay", 0)
        name = os.path.splitext(os.path.basename(path))[0] or "?"

        tile = tk.Frame(self.scroll_area.inner, bg=BG_CARD, cursor="hand2")
        tile.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

        icon_img = self._get_icon(path)
        if icon_img is not None:
            icon_label = tk.Label(tile, image=icon_img, bg=BG_CARD)
            icon_label.image = icon_img  # хранит ссылку, чтобы иконка не исчезла
        else:
            icon_label = tk.Label(tile, text="📦", font=("Segoe UI", 30), bg=BG_CARD, fg=ACCENT)
        icon_label.pack(pady=(15, 6))

        name_label = tk.Label(
            tile, text=name, font=("Segoe UI", 10, "bold"), bg=BG_CARD, fg=TEXT_MAIN,
            wraplength=120, justify="center",
        )
        name_label.pack(padx=8)

        delay_label = tk.Label(
            tile, text=f"⏱ {delay} сек", font=FONT_SMALL, bg=BG_CARD, fg=TEXT_DIM,
        )
        delay_label.pack(pady=(2, 15))

        for widget in (tile, icon_label, name_label, delay_label):
            widget.bind("<Button-1>", lambda e, i=index: self._select_program(i))

    def _select_program(self, index):
        self.selected_program_index = index
        for tile in self.scroll_area.inner.winfo_children():
            if not isinstance(tile, tk.Frame):
                continue
            bg = BG_CARD
            tile.configure(bg=bg)
            for child in tile.winfo_children():
                child.configure(bg=bg)

        tiles = [w for w in self.scroll_area.inner.winfo_children() if isinstance(w, tk.Frame)]
        if 0 <= index < len(tiles):
            tile = tiles[index]
            tile.configure(bg=BG_CARD_SELECTED)
            for child in tile.winfo_children():
                child.configure(bg=BG_CARD_SELECTED)

    def _get_icon(self, path):
        if path in self.icon_cache:
            return self.icon_cache[path]
        img = extract_icon(path, size=48)
        self.icon_cache[path] = img
        return img

    def add_program(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return

        initial_dir = DESKTOP_DIR if os.path.isdir(DESKTOP_DIR) else os.path.expanduser("~")
        dialog = AddProgramDialog(self.root, initial_dir)

        if not dialog.result:
            return

        self.scenarios[scenario].append(dialog.result)
        self.save_scenarios()
        self.load_programs()

    def remove_program(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        if self.selected_program_index is None:
            messagebox.showwarning("Внимание", "Сначала выберите программу (кликните по плитке).")
            return

        programs = self.scenarios[scenario]
        if self.selected_program_index >= len(programs):
            return

        del programs[self.selected_program_index]
        self.selected_program_index = None
        self.save_scenarios()
        self.load_programs()

    # ---------------------------------------------------------------
    # Запуск / остановка
    # ---------------------------------------------------------------

    def run_scenario(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return

        programs = list(self.scenarios[scenario])
        if not programs:
            messagebox.showinfo("Fast Start", "В сценарии нет программ.")
            return

        def worker():
            count = 0
            for item in programs:
                delay = item.get("delay", 0)
                time.sleep(delay)
                try:
                    os.startfile(item["path"])
                    count += 1
                except Exception as e:
                    self.root.after(0, lambda e=e: messagebox.showerror("Ошибка", str(e)))

            self.root.after(
                0, lambda: messagebox.showinfo("Готово", f"Запущено программ: {count}")
            )

        threading.Thread(target=worker, daemon=True).start()

    def stop_scenario(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return

        closed = 0
        for program in self.scenarios[scenario]:
            raw_path = program.get("path", "")
            if not raw_path:
                continue
            real_path = resolve_shortcut_target(raw_path)
            exe_name = os.path.basename(real_path).lower()
            if not exe_name:
                continue
            for proc in psutil.process_iter(["name"]):
                try:
                    if proc.info["name"] and proc.info["name"].lower() == exe_name:
                        proc.terminate()
                        closed += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

        messagebox.showinfo("Fast Start", f"Закрыто процессов: {closed}")


if __name__ == "__main__":
    root = tk.Tk()
    app = FastStart(root)
    root.mainloop()