"""Fast Start — запускатель нескольких приложений сценариями."""

import io
import json
import os
import struct
import sys
import threading
import time
import urllib.parse

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import psutil

# ---------- Иконки: опционально. Если pywin32 / Pillow не установлены,
# программа работает, но с заглушками. Установка: pip install pywin32 Pillow
try:
    from PIL import Image, ImageTk
    import win32gui
    import win32ui
    import win32com.client
    ICONS_AVAILABLE = True
except ImportError:
    ICONS_AVAILABLE = False

# Флаги SHGetFileInfo — та же функция Windows, которой пользуется
# Проводник и Рабочий стол для иконок (в т.ч. у ярлыков .lnk).
SHGFI_ICON = 0x000000100
SHGFI_LARGEICON = 0x000000000

DESKTOP_DIR = os.path.join(os.path.expanduser("~"), "Desktop")

# Файл сценариев — привязан к каталогу приложения (важно для .exe после сборки),
# а не к текущей директории.
if getattr(sys, "frozen", False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCENARIOS_FILE = os.path.join(_BASE_DIR, "scenarios.json")

# ---------------- Темы
THEMES = {
    "dark": {
        "BG_MAIN": "#121212",
        "BG_PANEL": "#1a1a1a",
        "BG_CARD": "#232323",
        "BG_CARD_SELECTED": "#2f2f36",
        "ACCENT_BG": "#2e2e34",
        "ACCENT": "#00d4ff",
        "ACCENT_GREEN": "#00e07a",
        "ACCENT_RED": "#ff4d4d",
        "ACCENT_ORANGE": "#ffaa00",
        "TEXT_MAIN": "#f2f2f2",
        "TEXT_DIM": "#9a9a9a",
        "TEXT_SELECTION": "#0b1f33",
    },
    "light": {
        "BG_MAIN": "#eef1f6",
        "BG_PANEL": "#ffffff",
        "BG_CARD": "#e6ebf4",
        "BG_CARD_SELECTED": "#c9ddef",
        "ACCENT_BG": "#e5e7eb",
        "ACCENT": "#0077c8",
        "ACCENT_GREEN": "#0a9d4f",
        "ACCENT_RED": "#d7263d",
        "ACCENT_ORANGE": "#e2711d",
        "TEXT_MAIN": "#1f2937",
        "TEXT_DIM": "#6b7280",
        "TEXT_SELECTION": "#10243e",
    },
}
CURRENT_THEME = "dark"


def C(key):
    """Цвет текущей темы."""
    return THEMES[CURRENT_THEME][key]


# ---------------- Шрифты
FONT_TITLE = ("Segoe UI", 20, "bold")
FONT_SUBTITLE = ("Segoe UI", 10)
FONT_HEADER = ("Segoe UI", 13, "bold")
FONT_NORMAL = ("Segoe UI", 10)
FONT_SMALL = ("Segoe UI", 9)


# ---------------------------------------------------------------------------
# Иконки
# ---------------------------------------------------------------------------

def resolve_shortcut_target(path):
    """Если это ярлык (.lnk), возвращает путь к реальной программе."""
    if not path or not path.lower().endswith(".lnk"):
        return path
    if not ICONS_AVAILABLE:
        return path
    try:
        shell = win32com.client.Dispatch("WScript.Shell")
        target = shell.CreateShortcut(path).Targetpath
        if target:
            return target
    except Exception:
        pass
    return path


def extract_icon(path, size=48):
    """Извлекает настоящую иконку тем же способом, что Проводник
    (SHGetFileInfo) — работает и для .exe, и для .lnk.
    Возвращает PhotoImage или None, если не удалось."""
    if not ICONS_AVAILABLE or not path or not os.path.exists(path):
        return None

    hicon = None
    hdc_screen = None
    hdc = None
    hdc_mem = None
    hbmp = None
    try:
        info = win32gui.SHGetFileInfo(path, 0, SHGFI_ICON | SHGFI_LARGEICON)
        hicon = info[0]
        if not hicon:
            return None

        hdc_screen = win32gui.GetDC(0)
        hdc = win32ui.CreateDCFromHandle(hdc_screen)
        hbmp = win32ui.CreateBitmap()
        hbmp.CreateCompatibleBitmap(hdc, size, size)
        hdc_mem = hdc.CreateCompatibleDC()
        hdc_mem.SelectObject(hbmp)
        hdc_mem.DrawIcon((0, 0), hicon)

        bmpinfo = hbmp.GetInfo()
        w, h = bmpinfo["bmWidth"], bmpinfo["bmHeight"]
        data = hbmp.GetBitmapBits(True)
        data = data[: w * h * 4]  # ровно размер битмапа

        # Собираем в памяти валидный BMP (top-down, 32-бит)
        # и открываем через Image.open — без хрупких аргументов frombuffer.
        bmp = (
            struct.pack("<2sIhhI", b"BM", 54 + len(data), 0, 0, 54)
            + struct.pack("<IIIhhIIIIII", 40, w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
            + data
        )
        img = Image.open(io.BytesIO(bmp)).convert("RGBA")
        img = img.resize((size, size), Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None
    finally:
        if hicon:
            win32gui.DestroyIcon(hicon)
        if hbmp is not None:
            hbmp.Delete()
        if hdc_mem:
            hdc_mem.DeleteDC()
        if hdc:
            hdc.DeleteDC()
        if hdc_screen:
            win32gui.ReleaseDC(0, hdc_screen)


# ---------------------------------------------------------------------------
# Прокручиваемая область
# ---------------------------------------------------------------------------

class ScrollableFrame(tk.Frame):
    """Прокручиваемая область (список сценариев и сетка плиток)."""

    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)

        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)

        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._on_mousewheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def _on_canvas_resize(self, event):
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


# ---------------------------------------------------------------------------
# Диалог добавления программы (путь + задержка/ожидание + ▲▼)
# ---------------------------------------------------------------------------

class AddProgramDialog(tk.Toplevel):
    def __init__(self, parent, initial_dir):
        super().__init__(parent)
        self.result = None
        self.initial_dir = initial_dir

        self.title("Добавить программу")
        self.configure(bg=C("BG_PANEL"))
        self.resizable(False, False)
        self.transient(parent)

        self.path_var = tk.StringVar()
        self.delay_var = tk.IntVar(value=0)
        self.wait_var = tk.BooleanVar(value=False)

        tk.Label(
            self, text="Программа или ярлык", font=FONT_NORMAL,
            bg=C("BG_PANEL"), fg=C("TEXT_MAIN")
        ).pack(anchor="w", padx=20, pady=(20, 5))

        path_frame = tk.Frame(self, bg=C("BG_PANEL"))
        path_frame.pack(fill="x", padx=20)

        self.path_entry = tk.Entry(
            path_frame, textvariable=self.path_var, bg=C("BG_CARD"), fg=C("TEXT_MAIN"),
            relief="flat", state="readonly", readonlybackground=C("BG_CARD"),
            font=FONT_SMALL, width=40,
        )
        self.path_entry.pack(side="left", fill="x", expand=True, ipady=6)

        tk.Button(
            path_frame, text="Обзор...", command=self._browse, bg=C("ACCENT"), fg="black",
            relief="flat", font=FONT_SMALL, cursor="hand2", bd=0, padx=12, pady=4,
        ).pack(side="left", padx=(8, 0))

        tk.Label(self, text="Задержка запуска", font=FONT_NORMAL,
                 bg=C("BG_PANEL"), fg=C("TEXT_MAIN")).pack(anchor="w", padx=20, pady=(20, 5))

        delay_frame = tk.Frame(self, bg=C("BG_PANEL"))
        delay_frame.pack(padx=20, anchor="w")

        self.wait_cb = tk.Checkbutton(
            delay_frame,
            text="⏳ Ждать закрытия предыдущих приложений",
            variable=self.wait_var,
            command=self._sync_delay,
            bg=C("BG_PANEL"), fg=C("TEXT_MAIN"),
            selectcolor=C("BG_CARD"),
            activebackground=C("BG_PANEL"), activeforeground=C("TEXT_MAIN"),
            font=FONT_SMALL,
        )
        self.wait_cb.pack(side="left", ipady=4, padx=(0, 10))

        delay_sub = tk.Frame(delay_frame, bg=C("BG_PANEL"))
        delay_sub.pack(anchor="w")

        self.delay_spin = tk.Spinbox(
            delay_sub, from_=0, to=3600, textvariable=self.delay_var,
            width=8, font=("Segoe UI", 13), bg=C("BG_CARD"), fg=C("TEXT_MAIN"),
            relief="flat", buttonbackground=C("ACCENT"), insertbackground=C("TEXT_MAIN"),
            justify="center", wrap=False,
        )
        self.delay_spin.pack(side="left", ipady=8)
        tk.Label(delay_sub, text="сек", font=FONT_NORMAL, bg=C("BG_PANEL"), fg=C("TEXT_DIM")).pack(side="left", padx=(10, 0))

        btn_row = tk.Frame(self, bg=C("BG_PANEL"))
        btn_row.pack(fill="x", padx=20, pady=20)

        tk.Button(
            btn_row, text="Отмена", command=self._cancel, bg=C("ACCENT_BG"), fg=C("TEXT_MAIN"),
            relief="flat", font=FONT_NORMAL, cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right", padx=(8, 0))

        tk.Button(
            btn_row, text="Добавить", command=self._confirm, bg=C("ACCENT_GREEN"), fg="black",
            relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, padx=15, pady=8,
        ).pack(side="right")

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.update_idletasks()
        self._center_over(parent)

        self.grab_set()
        self.wait_window(self)

    def _center_over(self, parent):
        parent.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")

    def _sync_delay(self):
        self.delay_spin.config(state="disabled" if self.wait_var.get() else "normal")

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Выберите программу или ярлык",
            initialdir=self.initial_dir,
            parent=self,
            filetypes=[
                ("Программы и ярлыки", "*.exe *.lnk"),
                ("Программы (.exe)", "*.exe"),
                ("Ярлыки (.lnk)", "*.lnk"),
                ("Все файлы", "*.*"),
            ],
        )
        if path:
            self.path_var.set(path)

    def _confirm(self):
        path = self.path_var.get().strip()
        if not path:
            messagebox.showwarning("Внимание", "Сначала выберите программу.", parent=self)
            return
        try:
            delay = int(self.delay_var.get())
        except (tk.TclError, ValueError):
            delay = 0
        wait = bool(self.wait_var.get())
        self.result = {"path": path,
                       "delay": 0 if wait else max(0, delay),
                       "wait": wait}
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


# ---------------------------------------------------------------------------
# Основное приложение
# ---------------------------------------------------------------------------

class FastStart:
    def __init__(self, root):
        self.root = root
        self.root.title("🚀 Fast Start")
        self.root.geometry("1000x620")
        self.root.minsize(780, 480)
        self.root.configure(bg=C("BG_MAIN"))

        self.scenarios = self.load_scenarios()
        self.icon_cache = {}
        self.selected_scenario_name = None
        self.selected_program_index = None
        self.scenario_rows = {}

        # Запуск/стоп
        self._run_active = False
        self._stop_event = threading.Event()
        self._running_pids = set()

        self._build_ui()
        self._setup_drop()
        self.refresh_scenarios()

    # ---------------------------------------------------------------
    # Построение интерфейса
    # ---------------------------------------------------------------

    def _build_ui(self):
        # ---------------- Шапка ----------------
        header = tk.Frame(self.root, bg=C("BG_MAIN"))
        header.pack(fill="x", padx=20, pady=(15, 5))

        tk.Label(header, text="🚀 Fast Start", font=FONT_TITLE, bg=C("BG_MAIN"), fg=C("ACCENT")).pack(side="left")
        tk.Label(header, text="Менеджер сценариев запуска", font=FONT_SUBTITLE,
                 bg=C("BG_MAIN"), fg=C("TEXT_DIM")).pack(side="left", padx=(15, 0), pady=(7, 0))

        self.theme_btn = self._make_button(
            header, "☀️" if CURRENT_THEME == "dark" else "🌙",
            C("ACCENT_BG"), C("TEXT_MAIN"), self._switch_theme)
        self.theme_btn.pack(side="right", padx=(12, 0))

        main_frame = tk.Frame(self.root, bg=C("BG_MAIN"))
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # ---------------- Левая панель: сценарии ----------------
        left_frame = tk.Frame(main_frame, bg=C("BG_PANEL"), width=260)
        left_frame.pack(side="left", fill="y", padx=(0, 15))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Сценарии", font=FONT_HEADER, bg=C("BG_PANEL"), fg=C("TEXT_MAIN")).pack(pady=(15, 10), padx=15, anchor="w")

        list_area = tk.Frame(left_frame, bg=C("BG_PANEL"))
        list_area.pack(fill="both", expand=True, padx=15)
        self.scenario_scroll = ScrollableFrame(list_area, C("BG_PANEL"))
        self.scenario_scroll.pack(fill="both", expand=True)
        self.scenario_list_frame = self.scenario_scroll.inner

        btns = tk.Frame(left_frame, bg=C("BG_PANEL"))
        btns.pack(fill="x", padx=15, pady=15)
        self._make_button(btns, "➕ Создать", C("ACCENT"), "black", self.create_scenario).pack(fill="x", pady=3)
        self._make_button(btns, "✏ Переименовать", C("ACCENT_ORANGE"), "black", self.rename_scenario).pack(fill="x", pady=3)
        self._make_button(btns, "🗑 Удалить", C("ACCENT_RED"), "white", self.delete_scenario).pack(fill="x", pady=3)

        status_text = ("🟢 Иконки включены" if ICONS_AVAILABLE
                       else "⚪ Иконки выключены\npip install pywin32 Pillow")
        tk.Label(left_frame, text=status_text, font=FONT_SMALL, bg=C("BG_PANEL"),
                 fg=C("ACCENT_GREEN") if ICONS_AVAILABLE else C("TEXT_DIM"),
                 justify="left").pack(padx=15, pady=(0, 8), anchor="w")
        tk.Label(left_frame,
                 text="💡 Перетащите .exe / .lnk прямо в окно —\nдобавится в выбранный сценарий.",
                 font=FONT_SMALL, bg=C("BG_PANEL"), fg=C("TEXT_DIM"), justify="left").pack(padx=15, pady=(0, 15), anchor="w")

        # ---------------- Правая панель: программы ----------------
        right_frame = tk.Frame(main_frame, bg=C("BG_PANEL"))
        right_frame.pack(side="right", fill="both", expand=True)

        right_header = tk.Frame(right_frame, bg=C("BG_PANEL"))
        right_header.pack(fill="x", padx=20, pady=(15, 5))
        self.programs_title = tk.Label(right_header, text="Программы", font=FONT_HEADER, bg=C("BG_PANEL"), fg=C("TEXT_MAIN"))
        self.programs_title.pack(side="left")

        self.scroll_area = ScrollableFrame(right_frame, C("BG_PANEL"))
        self.scroll_area.pack(fill="both", expand=True, padx=15, pady=10)

        bottom_bar = tk.Frame(right_frame, bg=C("BG_PANEL"))
        bottom_bar.pack(fill="x", padx=20, pady=(0, 15))
        self._make_button(bottom_bar, "➕ Добавить программу", C("ACCENT"), "black", self.add_program).pack(side="left", padx=(0, 8))
        self._make_button(bottom_bar, "❌ Удалить программу", C("ACCENT_RED"), "white", self.remove_program).pack(side="left")
        self.stop_btn = self._make_button(bottom_bar, "⛔ Остановить", C("ACCENT_RED"), "white", self.stop_scenario, bold=True)
        self.stop_btn.pack(side="right", padx=(8, 0))
        self.run_btn = self._make_button(bottom_bar, "🚀 Запустить сценарий", C("ACCENT_GREEN"), "black", self.run_scenario, bold=True)
        self.run_btn.pack(side="right")

    def _make_button(self, parent, text, bg, fg, command, bold=False):
        return tk.Button(
            parent, text=text, command=command, bg=bg, fg=fg,
            relief="flat", activebackground=bg, activeforeground=fg,
            font=("Segoe UI", 10, "bold" if bold else "normal"),
            cursor="hand2", bd=0, padx=10, pady=8,
        )

    def _switch_theme(self):
        """Смена темы: пересобираем интерфейс в новой палитре
        (данные и выбор сценария сохраняются)."""
        global CURRENT_THEME
        CURRENT_THEME = "light" if CURRENT_THEME == "dark" else "dark"
        for w in self.root.winfo_children():
            w.destroy()
        self._build_ui()
        self.refresh_scenarios()

    # ---------------------------------------------------------------
    # Работа с файлом сценариев
    # ---------------------------------------------------------------

    def load_scenarios(self):
        """Читаем сценарии; при битом файле пробуем .bak."""
        for f in (SCENARIOS_FILE, SCENARIOS_FILE + ".bak"):
            if os.path.exists(f):
                try:
                    with open(f, "r", encoding="utf-8") as fh:
                        data = json.load(fh)
                    return data if isinstance(data, dict) else {}
                except (json.JSONDecodeError, OSError, TypeError):
                    continue
        return {}

    def save_scenarios(self):
        """Атомарное сохранение: временный файл + replace.
        Старый файл остаётся в .bak — данные не теряются."""
        tmp = SCENARIOS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.scenarios, f, ensure_ascii=False, indent=4)
        if os.path.exists(SCENARIOS_FILE):
            os.replace(SCENARIOS_FILE, SCENARIOS_FILE + ".bak")
        os.replace(tmp, SCENARIOS_FILE)

    # ---------------------------------------------------------------
    # Сценарии
    # ---------------------------------------------------------------

    def refresh_scenarios(self):
        for widget in self.scenario_list_frame.winfo_children():
            widget.destroy()
        self.scenario_rows = {}

        if self.selected_scenario_name not in self.scenarios:
            self.selected_scenario_name = None

        if not self.scenarios:
            tk.Label(self.scenario_list_frame, text="Нет сценариев.\nНажмите «Создать».",
                     font=FONT_SMALL, bg=C("BG_PANEL"), fg=C("TEXT_DIM"), justify="left").pack(pady=15, anchor="w")

        for name in self.scenarios:
            row = tk.Frame(self.scenario_list_frame, bg=C("BG_CARD"), cursor="hand2")
            row.pack(fill="x", pady=3)
            label = tk.Label(row, text=name, font=FONT_NORMAL, bg=C("BG_CARD"), fg=C("TEXT_MAIN"), anchor="w", padx=10, pady=8)
            label.pack(fill="x")
            for widget in (row, label):
                widget.bind("<Button-1>", lambda e, n=name: self.select_scenario(n))
            self.scenario_rows[name] = (row, label)

        if self.selected_scenario_name is None and self.scenarios:
            self.selected_scenario_name = next(iter(self.scenarios))

        self._highlight_scenario_selection()
        self.load_programs()

    def _highlight_scenario_selection(self):
        for name, (row, label) in self.scenario_rows.items():
            selected = name == self.selected_scenario_name
            row.configure(bg=C("ACCENT") if selected else C("BG_CARD"))
            label.configure(bg=C("ACCENT") if selected else C("BG_CARD"),
                           fg=C("TEXT_SELECTION") if selected else C("TEXT_MAIN"))

    def select_scenario(self, name):
        self.selected_scenario_name = name
        self._highlight_scenario_selection()
        self.load_programs()

    def get_selected_scenario(self):
        return self.selected_scenario_name

    def create_scenario(self):
        name = self._prompt_text("Создать сценарий", "Введите имя сценария:")
        if not name:
            return
        if name in self.scenarios:
            messagebox.showerror("Ошибка", "Такой сценарий уже существует.")
            return
        self.scenarios[name] = []
        self.selected_scenario_name = name
        self.save_scenarios()
        self.refresh_scenarios()

    def rename_scenario(self):
        old_name = self.get_selected_scenario()
        if not old_name:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        new_name = self._prompt_text("Переименование", "Новое имя:", initial=old_name)
        if not new_name or new_name == old_name:
            return
        if new_name in self.scenarios:
            messagebox.showerror("Ошибка", "Сценарий с таким именем уже существует.")
            return
        self.scenarios[new_name] = self.scenarios.pop(old_name)
        self.selected_scenario_name = new_name
        self.save_scenarios()
        self.refresh_scenarios()

    def delete_scenario(self):
        name = self.get_selected_scenario()
        if not name:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        if messagebox.askyesno("Удаление", f"Удалить сценарий «{name}»?"):
            del self.scenarios[name]
            self.selected_scenario_name = None
            self.save_scenarios()
            self.refresh_scenarios()

    def _prompt_text(self, title, message, initial=""):
        """Простое модальное окно ввода текста."""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg=C("BG_PANEL"))
        dialog.resizable(False, False)
        dialog.transient(self.root)
        result = {"value": None}

        tk.Label(dialog, text=message, font=FONT_NORMAL, bg=C("BG_PANEL"), fg=C("TEXT_MAIN")).pack(padx=20, pady=(20, 10), anchor="w")

        var = tk.StringVar(value=initial)
        entry = tk.Entry(dialog, textvariable=var, bg=C("BG_CARD"), fg=C("TEXT_MAIN"),
                         relief="flat", insertbackground=C("TEXT_MAIN"), font=FONT_NORMAL, width=30)
        entry.pack(padx=20, ipady=6, fill="x")
        entry.focus_set()
        entry.select_range(0, tk.END)

        def confirm():
            value = var.get().strip()
            if value:
                result["value"] = value
            dialog.destroy()

        def cancel():
            dialog.destroy()

        btn_row = tk.Frame(dialog, bg=C("BG_PANEL"))
        btn_row.pack(fill="x", padx=20, pady=20)
        tk.Button(btn_row, text="Отмена", command=cancel, bg=C("ACCENT_BG"), fg=C("TEXT_MAIN"),
                  relief="flat", font=FONT_NORMAL, cursor="hand2", bd=0, padx=15, pady=8).pack(side="right", padx=(8, 0))
        tk.Button(btn_row, text="ОК", command=confirm, bg=C("ACCENT_GREEN"), fg="black",
                  relief="flat", font=("Segoe UI", 10, "bold"), cursor="hand2", bd=0, padx=15, pady=8).pack(side="right")

        dialog.bind("<Return>", lambda e: confirm())
        dialog.bind("<Escape>", lambda e: cancel())
        dialog.protocol("WM_DELETE_WINDOW", cancel)

        dialog.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - dialog.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{max(x, 0)}+{max(y, 0)}")

        dialog.grab_set()
        dialog.wait_window(dialog)
        return result["value"]

    # ---------------------------------------------------------------
    # Программы (плитки с иконками)
    # ---------------------------------------------------------------

    def load_programs(self):
        for widget in self.scroll_area.inner.winfo_children():
            widget.destroy()
        self.selected_program_index = None

        name = self.get_selected_scenario()
        if not name:
            self.programs_title.config(text="Программы")
            tk.Label(self.scroll_area.inner, text="Выберите или создайте сценарий слева.",
                     font=FONT_NORMAL, bg=C("BG_PANEL"), fg=C("TEXT_DIM")).pack(pady=30)
            return

        programs = self.scenarios.get(name, [])
        self.programs_title.config(text=f"Программы — {name} ({len(programs)})")

        if not programs:
            tk.Label(self.scroll_area.inner, text="Сценарий пуст. Нажмите «Добавить программу».",
                     font=FONT_NORMAL, bg=C("BG_PANEL"), fg=C("TEXT_DIM")).pack(pady=30)
            return

        columns = 4
        for col in range(columns):
            self.scroll_area.inner.grid_columnconfigure(col, weight=1)

        for idx, item in enumerate(programs):
            row, col = divmod(idx, columns)
            self._create_program_tile(item, idx, row, col)

    def _create_program_tile(self, item, index, row, col):
        path = item.get("path", "")
        delay = item.get("delay", 0)
        wait = bool(item.get("wait", False))
        name = os.path.splitext(os.path.basename(path))[0] or "?"

        tile = tk.Frame(self.scroll_area.inner, bg=C("BG_CARD"), cursor="hand2")
        tile.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

        icon_img = self._get_icon(path)
        if icon_img is not None:
            icon_label = tk.Label(tile, image=icon_img, bg=C("BG_CARD"))
            icon_label.image = icon_img  # хранит ссылку, чтобы иконка не исчезла
        else:
            icon_label = tk.Label(tile, text="📦", font=("Segoe UI", 30), bg=C("BG_CARD"), fg=C("ACCENT"))
        icon_label.pack(pady=(15, 6))

        name_label = tk.Label(tile, text=name, font=("Segoe UI", 10, "bold"),
                              bg=C("BG_CARD"), fg=C("TEXT_MAIN"), wraplength=120, justify="center")
        name_label.pack(padx=8)

        if wait:
            delay_label = tk.Label(tile, text="⏳ ждать закрытия", font=FONT_SMALL,
                                   bg=C("BG_CARD"), fg=C("ACCENT_ORANGE"))
        else:
            delay_label = tk.Label(tile, text=f"⏱ {delay} сек", font=FONT_SMALL,
                                   bg=C("BG_CARD"), fg=C("TEXT_DIM"))
        delay_label.pack(pady=(2, 15))

        for widget in (tile, icon_label, name_label, delay_label):
            widget.bind("<Button-1>", lambda e, i=index: self._select_program(i))

    def _select_program(self, index):
        self.selected_program_index = index
        tiles = [w for w in self.scroll_area.inner.winfo_children() if isinstance(w, tk.Frame)]
        for tile in tiles:
            tile.configure(bg=C("BG_CARD"))
            for child in tile.winfo_children():
                child.configure(bg=C("BG_CARD"))
        if 0 <= index < len(tiles):
            tile = tiles[index]
            tile.configure(bg=C("BG_CARD_SELECTED"))
            for child in tile.winfo_children():
                child.configure(bg=C("BG_CARD_SELECTED"))

    def _get_icon(self, path):
        if path in self.icon_cache:
            return self.icon_cache[path]
        img = extract_icon(path, size=48)
        self.icon_cache[path] = img
        return img

    def add_program(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        initial_dir = DESKTOP_DIR if os.path.isdir(DESKTOP_DIR) else os.path.expanduser("~")
        dialog = AddProgramDialog(self.root, initial_dir)
        if not dialog.result:
            return
        self.scenarios[scenario].append(dialog.result)
        self.save_scenarios()
        self.load_programs()

    def remove_program(self):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        if self.selected_program_index is None:
            messagebox.showwarning("Внимание", "Сначала выберите программу (кликните по плитке).")
            return
        programs = self.scenarios[scenario]
        if self.selected_program_index >= len(programs):
            return
        del programs[self.selected_program_index]
        self.selected_program_index = None
        self.save_scenarios()
        self.load_programs()

    # ---------------------------------------------------------------
    # Drag & Drop: .exe / .lnk прямо в окно
    # ---------------------------------------------------------------

    def _setup_drop(self):
        """Включаем DnD в Tk (8.6+; в стандартном Python 3.10+ на Windows есть)."""
        try:
            self.root.drop_target_set(["URL", "FILE"])
        except (AttributeError, tk.TclError):
            return
        self.root.bind("<Drop>", self._on_drop)

    @staticmethod
    def _parse_drop(data):
        """Разбираем dnd_data в список путей (Tk даёт file:///C:/... или file://localhost/...)."""
        paths = []
        for part in (data or "").split("|"):
            part = part.strip()
            if not part:
                continue
            if part.lower().startswith("file:"):
                rest = part[5:]
                if rest.lower().startswith("//localhost/"):
                    rest = rest[12:]
                while rest.startswith("/"):
                    rest = rest[1:]
            else:
                rest = part
            rest = urllib.parse.unquote(rest)
            if rest:
                paths.append(os.path.normpath(rest))
        return paths

    def _on_drop(self, event):
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Drag & Drop", "Сначала выберите сценарий слева.")
            return
        paths = self._parse_drop(event.dnd_data)
        valid = [p for p in paths if p.lower().endswith((".exe", ".lnk"))]
        if not valid:
            messagebox.showinfo("Drag & Drop", "Среди перетащенных файлов нет .exe или .lnk.")
            return
        existing = {x.get("path", "").lower() for x in self.scenarios[scenario]}
        added = [p for p in valid if p.lower() not in existing]
        for p in added:
            self.scenarios[scenario].append({"path": p, "delay": 0, "wait": False})
        if added:
            self.save_scenarios()
            self.load_programs()
            messagebox.showinfo("Drag & Drop", f"Добавлено: {len(added)}")

    # ---------------------------------------------------------------
    # Запуск / остановка
    # ---------------------------------------------------------------

    def run_scenario(self):
        if self._run_active:
            return
        scenario = self.get_selected_scenario()
        if not scenario:
            messagebox.showwarning("Внимание", "Сначала выберите сценарий.")
            return
        programs = list(self.scenarios[scenario])
        if not programs:
            messagebox.showinfo("Fast Start", "В сценарии нет программ.")
            return

        # Названия exe для отслеживания (ярлыки резолвим в реальные программы)
        exe_names = set()
        for item in programs:
            target = resolve_shortcut_target(item.get("path") or "")
            name = os.path.basename(target).lower()
            if name:
                exe_names.add(name)

        # Запоминаем «уже работающие» процессы — при стопе убиваем только новые
        baseline = self._collect_pids(exe_names)
        self._running_pids = set()
        self._stop_event.clear()
        self._run_active = True
        self._set_run_status(f"⏳ Запущено: 0/{len(programs)}")

        def worker():
            done = 0
            chain_pids = set()
            for item in programs:
                if self._stop_event.is_set():
                    break
                path = item.get("path", "")
                if not path:
                    continue

                if item.get("wait"):
                    # Ждём, пока предыдущие приложения сценария закроются
                    if chain_pids:
                        while not self._stop_event.is_set():
                            alive = [p for p in chain_pids if self._is_alive(p)]
                            if not alive:
                                break
                            self._set_run_status(f"⏳ Ждём закрытия: {len(alive)}")
                            time.sleep(0.4)
                else:
                    delay = item.get("delay", 0)
                    if delay:
                        time.sleep(delay)
                        if self._stop_event.is_set():
                            break

                try:
                    os.startfile(path)
                except Exception as e:
                    self.root.after(0, lambda e=e: messagebox.showerror("Ошибка", str(e)))
                    continue
                done += 1
                new = self._find_new_pids(exe_names, baseline)
                chain_pids |= new
                self._running_pids |= new
                self._set_run_status(f"⏳ Запущено: {done}/{len(programs)}")

            self.root.after(0, lambda: self._run_finished(done))

        threading.Thread(target=worker, daemon=True).start()

    def stop_scenario(self):
        """Останавливаем сценарий: флаг для воркера + убиваем только
        процессы, запущенные самим Fast Start (по PID, а не по имени)."""
        if not self._run_active:
            return
        self._stop_event.set()
        self._set_run_status("⛔ Останавливаю…")
        for pid in list(self._running_pids):
            try:
                psutil.Process(pid).terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        self._running_pids = set()
        # Воркер заметит флаг и завершится → покажет «остановлено»

    def _run_finished(self, done):
        stopped = self._stop_event.is_set()
        self._stop_event.clear()
        self._run_active = False
        self._set_run_status("🚀 Запустить сценарий")

        def _msg():
            if stopped:
                messagebox.showinfo("Fast Start", "Сценарий остановлен.")
            else:
                messagebox.showinfo("Fast Start", f"Запущено программ: {done}")
        self.root.after(0, _msg)

    # ---------------------------------------------------------------
    # Вспомогательные
    # ---------------------------------------------------------------

    @staticmethod
    def _collect_pids(exe_names):
        try:
            return {p.pid for p in psutil.process_iter(["name"])
                    if exe_names and (p.info["name"] or "").lower() in exe_names}
        except Exception:
            return set()

    def _find_new_pids(self, exe_names, baseline):
        """Находит PID процессов, запущенных после baseline
        (с ретраями: процесс может появиться с задержкой)."""
        new = set()
        for _ in range(10):
            seen = {p.pid for p in psutil.process_iter(["name"])
                    if (p.info["name"] or "").lower() in exe_names}
            new = seen - baseline - self._running_pids
            self._running_pids |= new
            if new:
                break
            time.sleep(0.15)
        return new

    @staticmethod
    def _is_alive(pid):
        try:
            return psutil.pid_exists(pid)
        except Exception:
            return False

    def _set_run_status(self, text):
        self.root.after(0, lambda t=text: self.run_btn.config(text=t))


if __name__ == "__main__":
    root = tk.Tk()
    app = FastStart(root)
    root.mainloop()
